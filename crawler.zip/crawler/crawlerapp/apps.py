from django.apps import AppConfig


class CrawlerappConfig(AppConfig):
    name = 'crawlerapp'
